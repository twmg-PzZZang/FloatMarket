document.addEventListener("DOMContentLoaded", () => {

    const navbar = document.getElementById("navbar");

    if (!navbar) return;

    navbar.innerHTML = `
        <div class="logo">
            FloatMarket
        </div>

        <nav>
            <a href="index.html">Market</a>
            <a href="sell.html" id="sellLink">Sell</a>
            <a href="#">Inventory</a>
        </nav>

        <div class="navbar-right">

            <div class="theme-menu">

                <button
                    type="button"
                    class="theme-toggle"
                    id="themeToggle"
                    aria-label="Change theme"
                    title="Change theme"
                >
                    <svg
                        viewBox="0 0 24 24"
                        width="20"
                        height="20"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="1.8"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                    >
                        <path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 1.5-3.3 1.7 1.7 0 0 1 1.3-2.8H18a3 3 0 0 0 3-3 9 9 0 0 0-9-8.9Z"/>
                        <circle cx="7.5" cy="10" r="1"/>
                        <circle cx="10" cy="6.5" r="1"/>
                        <circle cx="15" cy="7.5" r="1"/>
                    </svg>
                </button>

                <div class="theme-dropdown" id="themeDropdown" hidden>

                    <div class="theme-dropdown-title">
                        Appearance
                    </div>

                    <button class="theme-option" data-theme-choice="noir">
                        <span class="theme-dot noir-dot"></span>
                        Noir
                        <span class="theme-check"></span>
                    </button>

                    <button class="theme-option" data-theme-choice="midnight">
                        <span class="theme-dot midnight-dot"></span>
                        Midnight Blue
                        <span class="theme-check"></span>
                    </button>

                    <button class="theme-option" data-theme-choice="emerald">
                        <span class="theme-dot emerald-dot"></span>
                        Emerald
                        <span class="theme-check"></span>
                    </button>

                    <button class="theme-option" data-theme-choice="crimson">
                        <span class="theme-dot crimson-dot"></span>
                        Crimson
                        <span class="theme-check"></span>
                    </button>

                    <button class="theme-option" data-theme-choice="light">
                        <span class="theme-dot light-dot"></span>
                        Light
                        <span class="theme-check"></span>
                    </button>

                </div>
            </div>

            <div class="account">

                <button class="account-button" id="accountButton">
                    Sign In
                </button>

                <div class="account-menu" id="accountMenu" hidden>

                    <a href="#">Profile</a>
                    <a href="#">Inventory</a>
                    <a href="#">Purchases</a>

                    <div class="menu-divider"></div>

                    <button id="signOut">
                        Sign Out
                    </button>

                </div>

            </div>

        </div>
    `;


    /* =========================
       LOGIN
    ========================= */

    const savedUser = sessionStorage.getItem("user");

    const sellLink = document.getElementById("sellLink");
    const accountButton = document.getElementById("accountButton");
    const accountMenu = document.getElementById("accountMenu");
    const signOut = document.getElementById("signOut");


    if (savedUser) {

        const user = JSON.parse(savedUser);

        sellLink.style.display = "inline";
        accountButton.textContent =
            `${user.username || "Account"} ▼`;

    } else {

        sellLink.style.display = "none";
        accountButton.textContent = "Sign In";

    }


    /* =========================
       ACCOUNT MENU
    ========================= */

    accountButton.addEventListener("click", (event) => {

        event.stopPropagation();

        if (!savedUser) {
            window.location.href = "login.html";
            return;
        }

        accountMenu.hidden = !accountMenu.hidden;

    });


    signOut.addEventListener("click", () => {

        sessionStorage.removeItem("user");

        window.location.href = "index.html";

    });


    /* =========================
       THEME
    ========================= */

    const themeToggle =
        document.getElementById("themeToggle");

    const themeDropdown =
        document.getElementById("themeDropdown");

    const themeOptions =
        document.querySelectorAll(".theme-option");


    function applyTheme(theme) {

        document.documentElement.dataset.theme = theme;

        localStorage.setItem(
            "floatMarketTheme",
            theme
        );


        themeOptions.forEach(option => {

            const selected =
                option.dataset.themeChoice === theme;

            option.classList.toggle(
                "active",
                selected
            );

            const check =
                option.querySelector(".theme-check");

            if (check) {
                check.textContent =
                    selected ? "✓" : "";
            }

        });

    }


    themeToggle.addEventListener("click", (event) => {

        event.stopPropagation();

        themeDropdown.hidden =
            !themeDropdown.hidden;

    });


    themeOptions.forEach(option => {

        option.addEventListener("click", () => {

            applyTheme(
                option.dataset.themeChoice
            );

            themeDropdown.hidden = true;

        });

    });


    /* =========================
       CLOSE MENUS
    ========================= */

    document.addEventListener("click", (event) => {

        if (!event.target.closest(".theme-menu")) {
            themeDropdown.hidden = true;
        }

        if (!event.target.closest(".account")) {
            accountMenu.hidden = true;
        }

    });


    /* =========================
       SAVED THEME
    ========================= */

    applyTheme(
        localStorage.getItem("floatMarketTheme") || "noir"
    );

});