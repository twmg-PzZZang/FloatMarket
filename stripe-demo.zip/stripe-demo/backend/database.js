const Database = require("better-sqlite3");

const db = new Database("database.db");

// USERS
db.prepare(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
`).run();


// ITEMS
db.prepare(`
    CREATE TABLE IF NOT EXISTS items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        weapon TEXT NOT NULL,
        name TEXT NOT NULL,
        condition TEXT,
        float_value REAL,
        image TEXT
    )
`).run();


// LISTINGS
db.prepare(`
    CREATE TABLE IF NOT EXISTS listings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id INTEGER NOT NULL,
        seller_id INTEGER,
        price REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'available',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (item_id) REFERENCES items(id),
        FOREIGN KEY (seller_id) REFERENCES users(id)
    )
`).run();


// ADD THE CURRENT SKINS IF THEY DON'T EXIST
const itemCount = db.prepare(`
    SELECT COUNT(*) AS count
    FROM items
`).get();

if (itemCount.count === 0) {

    const insertItem = db.prepare(`
        INSERT INTO items
        (weapon, name, condition, float_value, image)
        VALUES (?, ?, ?, ?, ?)
    `);

    insertItem.run(
        "AK-47",
        "Fuel Injector",
        "Field-Tested",
        0.2381,
        "../images/fuel.png"
    );

    insertItem.run(
        "AWP",
        "Neo-Noir",
        "Minimal Wear",
        0.0872,
        "../images/neo.png"
    );
    insertItem.run(
        "M9 Bayonet",
        "Doppler Phase 4",
        "Factory New",
        0.0018,
        "../images/m9phase4.png"
    );
    insertItem.run(
        "AK-47",
        "Fire Serpent",
        "Factory New",
        0.181,
        "../images/fire.png"
    );
    insertItem.run(
        "Sport Gloves",
        "Vice",
        "Factory New",
        0.081,
        "../images/vice.png"
    );
    insertItem.run(
        "Desert Eagle",
        "Printstream",
        "Factory New",
        0.081,
        "../images/printstreamdeagle.png"
    );
    insertItem.run(
        "Capsule",
        "EMS Katowice 2014 Challengers",
        "ㅤ",
        "ㅤ",
        "../images/EMS 2014.png"
    );
}   


// ADD STARTER LISTINGS
const listingCount = db.prepare(`
    SELECT COUNT(*) AS count
    FROM listings
`).get();

if (listingCount.count === 0) {

    const fuelInjector = db.prepare(`
        SELECT id
        FROM items
        WHERE weapon = 'AK-47'
        AND name = 'Fuel Injector'
    `).get();

    const neoNoir = db.prepare(`
        SELECT id
        FROM items
        WHERE weapon = 'AWP'
        AND name = 'Neo-Noir'
    `).get();

    const m9Bayonet = db.prepare(`
        SELECT id
        FROM items
        WHERE weapon = 'M9 Bayonet'
        AND name = 'Doppler Phase 4'
    `).get();

    const fireSerpent = db.prepare(`
        SELECT id
        FROM items
        WHERE weapon = 'AK-47'
        AND name = 'Fire Serpent'
    `).get();
    const vice = db.prepare(`
        SELECT id
        FROM items
        WHERE weapon = 'Sport Gloves'
        AND name = 'Vice'
    `).get();

    const printstream = db.prepare(`
        SELECT id
        FROM items
        WHERE weapon = 'Desert Eagle'
        AND name = 'Printstream'
    `).get();
    const emsCapsule = db.prepare(`
        SELECT id
        FROM items
        WHERE weapon = 'Capsule'
        AND name = 'EMS Katowice 2014 Challengers'
    `).get();

    if (fuelInjector) {
        db.prepare(`
            INSERT INTO listings
            (item_id, price)
            VALUES (?, ?)
        `).run(
            fuelInjector.id,
            92.50
        );
    }


    if (neoNoir) {
        db.prepare(`
            INSERT INTO listings
            (item_id, price)
            VALUES (?, ?)
        `).run(
            neoNoir.id,
            64.00
        );
    }
    if (m9Bayonet) {
        db.prepare(`
            INSERT INTO listings
            (item_id, price)
            VALUES (?, ?)
        `).run(
            m9Bayonet.id,
            3000.00
        );
    }
    if (fireSerpent) {
        db.prepare(`
            INSERT INTO listings
            (item_id, price)
            VALUES (?, ?)
        `).run(
            fireSerpent.id,
            150.00
        );
    }
    if (vice) {
        db.prepare(`
            INSERT INTO listings
            (item_id, price)
            VALUES (?, ?)
        `).run(
            vice.id,
            10000.00
        );
    }
    if (printstream) {
        db.prepare(`
            INSERT INTO listings
            (item_id, price)
            VALUES (?, ?)
        `).run(
            printstream.id,
            200.00
        );
    }
    if (emsCapsule) {
        db.prepare(`
            INSERT INTO listings
            (item_id, price)
            VALUES (?, ?)
        `).run(
            emsCapsule.id,
            500.00
        );
    }

}
console.log("Database connected.");
console.log("Users table ready.");
console.log("Items table ready.");
console.log("Listings table ready.");

module.exports = db;