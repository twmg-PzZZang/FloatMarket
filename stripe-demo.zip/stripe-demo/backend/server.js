
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const Stripe = require("stripe");
const bcrypt = require("bcrypt");

const db = require("./database");

const app = express();

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.send("Stripe backend is running!");
});

app.post("/register", async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Check all fields exist
        if (!username || !email || !password) {
            return res.status(400).json({
                error: "Please fill in all fields."
            });
        }

        // Check if username or email already exists
        const existingUser = db.prepare(`
            SELECT id FROM users
            WHERE username = ? OR email = ?
        `).get(username, email);

        if (existingUser) {
            return res.status(400).json({
                error: "Username or email already exists."
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 12);

        // Save user
        const result = db.prepare(`
            INSERT INTO users (username, email, password)
            VALUES (?, ?, ?)
        `).run(username, email, hashedPassword);

        res.json({
            message: "Account created successfully!",
            userId: result.lastInsertRowid
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "Something went wrong."
        });
    }
});

app.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check fields
        if (!email || !password) {
            return res.status(400).json({
                error: "Please enter your email and password."
            });
        }

        // Find user
        const user = db.prepare(`
            SELECT id, username, email, password
            FROM users
            WHERE email = ?
        `).get(email);

        if (!user) {
            return res.status(401).json({
                error: "Invalid email or password."
            });
        }

        // Check password
        const passwordMatch = await bcrypt.compare(
            password,
            user.password
        );

        if (!passwordMatch) {
            return res.status(401).json({
                error: "Invalid email or password."
            });
        }

        // Successful login
        res.json({
            message: "Login successful!",
            user: {
                id: user.id,
                username: user.username,
                email: user.email
            }
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "Something went wrong."
        });
    }
});

// Get items for the market
app.get("/items", (req, res) => {
    try {
        const items = db.prepare(`
            SELECT *
            FROM items
        `).all();

        res.json(items);

    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "Unable to load items."
        });
    }
});



// GET ALL AVAILABLE MARKET LISTINGS
app.get("/listings", (req, res) => {

    try {

        const listings = db.prepare(`
            SELECT
                listings.id,
                listings.price,
                listings.status,
                listings.created_at,

                items.weapon,
                items.name,
                items.condition,
                items.float_value,
                items.image,

                users.username AS seller

            FROM listings

            JOIN items
                ON listings.item_id = items.id

            LEFT JOIN users
                ON listings.seller_id = users.id

            WHERE listings.status = 'available'

            ORDER BY listings.created_at DESC
        `).all();


        res.json(listings);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            error: "Unable to load listings."
        });

    }

});

app.post("/create-checkout-session", async (req, res) => {

    try {

        const { listingId } = req.body;


        const listing = db.prepare(`
            SELECT
                listings.id,
                listings.price,
                listings.status,
                items.weapon,
                items.name

            FROM listings

            JOIN items
                ON listings.item_id = items.id

            WHERE listings.id = ?
        `).get(listingId);


        if (!listing) {

            return res.status(404).json({
                error: "Listing not found."
            });

        }


        if (listing.status !== "available") {

            return res.status(400).json({
                error: "This item is no longer available."
            });

        }


        const session =
            await stripe.checkout.sessions.create({

                mode: "payment",

                line_items: [

                    {

                        price_data: {

                            currency: "gbp",

                            product_data: {

                                name:
                                    `${listing.weapon} ${listing.name}`

                            },

                            unit_amount:
                                Math.round(
                                    listing.price * 100
                                )

                        },

                        quantity: 1

                    }

                ],

                success_url:
                    "http://localhost:3000/success.html",

                cancel_url:
                    "http://localhost:3000/cancel.html"

            });


        res.json({
            url: session.url
        });


    } catch (error) {

        console.error(error);

        res.status(500).json({
            error: "Unable to create checkout session."
        });

    }

});
app.get("/items", (req, res) => {

    try {

        const items = db.prepare(`
            SELECT *
            FROM items
            ORDER BY weapon, name
        `).all();


        res.json(items);

    } catch (error) {

        console.error(error);

        res.status(500).json({
            error: "Unable to load items."
        });

    }

});
// CREATE A NEW LISTING
app.post("/listings", (req, res) => {

    try {

        const { item_id, price } = req.body;

        // Check that the item exists
        const item = db.prepare(`
            SELECT id
            FROM items
            WHERE id = ?
        `).get(item_id);

        if (!item) {
            return res.status(404).json({
                error: "Item does not exist."
            });
        }


        // Check price
        if (!price || price <= 0) {
            return res.status(400).json({
                error: "Price must be greater than £0."
            });
        }


        // Get the logged-in user
        // TEMPORARY: we'll connect this properly to authentication
        const seller_id = 1;


        // Create listing
        const result = db.prepare(`
            INSERT INTO listings
            (item_id, seller_id, price, status)
            VALUES (?, ?, ?, 'available')
        `).run(
            item_id,
            seller_id,
            price
        );


        res.json({
            success: true,
            listingId: result.lastInsertRowid
        });


    } catch (error) {

        console.error(error);

        res.status(500).json({
            error: "Unable to create listing."
        });

    }

});

const PORT = 4242;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});